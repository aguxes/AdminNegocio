package View;

import Clases.Principales.Cliente;
import Clases.Principales.Empleado;
import Clases.Principales.Producto;
import Clases.Principales.Venta;
import DataBase.DataBaseConnection;
import DataBase.*;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import util.Mapper;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;

import static View.AppController.agregarDobleClickSeleccion;
import static View.AppController.mostrarAlerta; // te copie papu

public class VentanaVentas {
    @FXML private TextArea outputArea;
    @FXML private VBox contenedor;

    private static final Connection conn = DataBaseConnection.getConnection();

    public VentanaVentas(VBox contenedor, TextArea outputArea) {
        this.contenedor = contenedor;
        this.outputArea = outputArea;
    }

    public void verVentas() {
        contenedor.getChildren().clear();

        VBox tarjeta = new VBox(15);
        tarjeta.setPadding(new Insets(20));
        tarjeta.setAlignment(Pos.TOP_CENTER);
        tarjeta.setMaxWidth(Double.MAX_VALUE);
        tarjeta.getStyleClass().add("card");

        // Título
        Label titulo = new Label("📊 Lista de Ventas");
        titulo.getStyleClass().add("titulo-seccion");

        // Barra de búsqueda por cliente
        HBox barraSuperior = new HBox(10);
        barraSuperior.setAlignment(Pos.CENTER_LEFT);

        Label lblBuscar = new Label("🔍 Ver por Cliente:");
        TextField campoCliente = new TextField();
        campoCliente.setPromptText("ID Cliente");
        campoCliente.setPrefWidth(120);

        Button btnAbrirLista = new Button("Seleccionar Cliente");
        btnAbrirLista.getStyleClass().add("btn-azul");

        // Acción para abrir la ventana de selección
        btnAbrirLista.setOnAction(e -> mostrarVentanaSeleccionCliente(campoCliente));

        Button btnFiltrar = new Button("Buscar");
        btnFiltrar.getStyleClass().add("btn-verde");

        barraSuperior.getChildren().addAll(lblBuscar, campoCliente, btnAbrirLista, btnFiltrar);

        // Tabla de ventas
        TableView<Venta> tabla = new TableView<>();
        tabla.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        tabla.setPlaceholder(new Label("No hay ventas cargadas."));
        tabla.getStyleClass().add("tabla-clientes");

        TableColumn<Venta, Integer> colFactura = new TableColumn<>("Factura");
        colFactura.setCellValueFactory(new PropertyValueFactory<>("idVenta"));

        TableColumn<Venta, String> colCliente = new TableColumn<>("Cliente");
        colCliente.setCellValueFactory(new PropertyValueFactory<>("nombreCliente"));

        TableColumn<Venta, String> colEmpleado = new TableColumn<>("Empleado");
        colEmpleado.setCellValueFactory(new PropertyValueFactory<>("nombreEmpleado"));

        TableColumn<Venta, String> colProducto = new TableColumn<>("Producto");
        colProducto.setCellValueFactory(new PropertyValueFactory<>("notas"));

        TableColumn<Venta, Integer> colCantidad = new TableColumn<>("Cantidad");
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));

        TableColumn<Venta, String> colFecha = new TableColumn<>("Fecha");
        colFecha.setCellValueFactory(new PropertyValueFactory<>("fechaFormateada"));

        TableColumn<Venta, String> colPago = new TableColumn<>("Pago");
        colPago.setCellValueFactory(new PropertyValueFactory<>("medioPago"));

        TableColumn<Venta, Double> colSubtotal = new TableColumn<>("Subtotal");
        colSubtotal.setCellValueFactory(new PropertyValueFactory<>("subtotal"));

        TableColumn<Venta, Double> colTotal = new TableColumn<>("Total");
        colTotal.setCellValueFactory(new PropertyValueFactory<>("importeTotal"));

        tabla.getColumns().addAll(
                colFactura, colCliente, colEmpleado, colProducto,
                colCantidad, colFecha, colPago, colSubtotal, colTotal
        );

        // Cargar todas las ventas por defecto
        ArrayList<Venta> lista = VentaDAO.cargarVentasEnLista();
        tabla.getItems().addAll(lista);

        Label lblCantidad = new Label("Total de ventas: " + lista.size());
        lblCantidad.getStyleClass().add("label-cantidad");

        // Acción del botón de búsqueda
        btnFiltrar.setOnAction(e -> {
            String idTexto = campoCliente.getText().trim();
            if (idTexto.isEmpty()) {
                ArrayList<Venta> todas = VentaDAO.cargarVentasEnLista();
                tabla.getItems().setAll(todas);
                lblCantidad.setText("Total de ventas: " + todas.size());
            } else {
                try {
                    int idCliente = Integer.parseInt(idTexto);
                    ArrayList<Venta> filtradas = VentaDAO.obtenerVentasPorCliente(idCliente);
                    tabla.getItems().setAll(filtradas);
                    lblCantidad.setText("Ventas del cliente: " + filtradas.size());
                } catch (NumberFormatException ex) {
                    mostrarAlerta("ID inválido.");
                }
            }
        });


        VBox.setVgrow(tarjeta, Priority.ALWAYS); // Esto permite que se expanda verticalmente si hay espacio
        VBox.setVgrow(tabla, Priority.ALWAYS);
        tabla.setMaxHeight(Double.MAX_VALUE); // para que no se achique


        // Armado final
        tarjeta.getChildren().addAll(titulo, barraSuperior, tabla, lblCantidad);
        contenedor.getChildren().setAll(tarjeta);
    }




    public void registrarVenta() {
        contenedor.getChildren().clear();

        VBox form = new VBox(10);
        form.setPadding(new Insets(20));
        form.getStyleClass().add("form-box");

        Label titulo = new Label("📋 Registrar Venta");
        titulo.getStyleClass().add("titulo-principal");

        TextField txtProductoId = new TextField();
        txtProductoId.setPromptText("ID Producto");
        txtProductoId.getStyleClass().add("text-field");

        Label lblCantidad = new Label("Cantidad:");
        TextField txtCantidad = new TextField();
        txtCantidad.setPromptText("Ej: 3");

        Button btnAgregarProducto = new Button(" Agregar Producto");
        btnAgregarProducto.getStyleClass().add("boton-secundario");
        VentanaProducto ventanaProducto = new VentanaProducto(contenedor, outputArea);
        btnAgregarProducto.setOnAction(e -> ventanaProducto.mostrarVentanaSeleccionProducto(txtProductoId));

        TextField txtClienteId = new TextField();
        txtClienteId.setPromptText("ID Cliente");
        txtClienteId.getStyleClass().add("text-field");

        TextField txtEmpleadoId = new TextField();
        txtEmpleadoId.setPromptText("ID Empleado");
        txtEmpleadoId.getStyleClass().add("text-field");

        ComboBox<String> medioPago = new ComboBox<>();
        medioPago.getItems().addAll("Efectivo", "Crédito", "Débito", "Transferencia");
        medioPago.setPromptText("Medio de Pago");
        medioPago.getStyleClass().add("choice-box");

        Label lblTotalVenta = new Label("Total de la venta: $0.00");
        lblTotalVenta.getStyleClass().add("etiqueta-total"); // opcional si tenés CSS


        Button btnAgregarCliente = new Button(" Agregar Cliente");
        btnAgregarCliente.getStyleClass().add("boton-secundario");
        btnAgregarCliente.setOnAction(e -> mostrarVentanaSeleccionCliente(txtClienteId));

        Button btnAgregarEmpleado = new Button(" Agregar Empleado");
        btnAgregarEmpleado.getStyleClass().add("boton-secundario");
        btnAgregarEmpleado.setOnAction(e -> mostrarVentanaSeleccionEmpleado(txtEmpleadoId));

        Button btnRegistrar = new Button("✅ Registrar Venta");
        btnRegistrar.getStyleClass().add("boton-accion");

        Runnable actualizarTotal = () -> {
            try {
                int cantidad = Integer.parseInt(txtCantidad.getText().trim());
                int idProd = Integer.parseInt(txtProductoId.getText().trim());
                Producto p = ProductoDAO.obtenerProductoPorID(idProd);
                if (p != null) {
                    BigDecimal precio = p.getPrecioUnitario();
                    BigDecimal total = precio.multiply(BigDecimal.valueOf(cantidad));
                    lblTotalVenta.setText("Total de la venta: $" + total);
                }
            } catch (Exception e) {
                lblTotalVenta.setText("Total de la venta: $0.00");
            }
        };

        btnRegistrar.setOnAction(e -> {
            try {
                int productoId = Integer.parseInt(txtProductoId.getText().trim());
                int clienteId = Integer.parseInt(txtClienteId.getText().trim());
                int empleadoId = Integer.parseInt(txtEmpleadoId.getText().trim());
                int cantidad =  Integer.parseInt(txtCantidad.getText().trim());
                String medio = medioPago.getValue();

                Producto prod = ProductoDAO.obtenerProductoPorID(productoId);
                if (prod == null) {
                    mostrarAlerta("❌ Producto no encontrado.");
                    return;
                }
                BigDecimal precio = prod.getPrecioUnitario();
                BigDecimal subtotal =  precio.multiply(BigDecimal.valueOf(cantidad));
                BigDecimal total = subtotal; //El subtotal es para calcular los descuentos y cualquier extra que se le sume o reste a la venta antes de dar el total final de la venta

                int idPago = switch (medio) {
                    case "Efectivo" -> 1;
                    case "Crédito" -> 2;
                    case "Débito" -> 3;
                    case "Transferencia" -> 4;
                    default -> throw new IllegalArgumentException("Forma de pago inválida.");
                };

                Venta venta = new Venta(); // Forma de reducir lineas aca?? Mapper extra o que??
                venta.setIdProducto(productoId);
                venta.setIdCliente(clienteId);
                venta.setIdEmpleado(empleadoId);
                venta.setIdFormaDePago(idPago);
                venta.setCantidad(cantidad);
                venta.setSubtotal(total);
                venta.setImporteTotal(total);

                String sql = "INSERT INTO Venta (idProd, idC, idE, formaDePago, cantidad, fecha, subtotal, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);

                Mapper.setVenta(stmt, venta);
                stmt.executeUpdate();
                mostrarAlerta("✅ Venta registrada correctamente.");
                contenedor.getChildren().clear();
                contenedor.getChildren().add(outputArea);

                boolean exito = VentaDAO.actualizarStockProducto(productoId, cantidad);
                if (!exito) {
                    mostrarAlerta("⚠ No se pudo actualizar el stock.");
                }

            } catch (Exception ex) {
                mostrarAlerta("❌ Error: " + ex.getMessage());
            }
        });

        txtCantidad.textProperty().addListener((obs, oldVal, newVal) -> actualizarTotal.run());
        txtProductoId.textProperty().addListener((obs, oldVal, newVal) -> actualizarTotal.run());

        //Al crear esto asi puedo darle un estilo mas cool
        HBox filaProducto = new HBox(15, btnAgregarProducto, txtProductoId);
        filaProducto.setAlignment(Pos.CENTER);

        HBox filaCliente = new HBox(15, btnAgregarCliente, txtClienteId);
        filaCliente.setAlignment(Pos.CENTER);

        HBox filaEmpleado = new HBox(15, btnAgregarEmpleado, txtEmpleadoId);
        filaEmpleado.setAlignment(Pos.CENTER);

        HBox filaCantidad = new HBox(15, lblCantidad, txtCantidad);
        filaCantidad.setAlignment(Pos.CENTER);

        form.setAlignment(Pos.TOP_CENTER);
        btnAgregarProducto.setPrefWidth(140);
        btnAgregarCliente.setPrefWidth(140);
        btnAgregarEmpleado.setPrefWidth(140);

        txtProductoId.setPrefWidth(200);
        txtClienteId.setPrefWidth(200);
        txtEmpleadoId.setPrefWidth(200);
        txtCantidad.setPrefWidth(200);
        // hasta aca, dsp los agregas abajo y list
        form.getChildren().addAll(
                titulo,
                filaProducto,
                filaCantidad,
                filaCliente,
                filaEmpleado,
                medioPago,
                lblTotalVenta,
                btnRegistrar
        );

        Button btnCancelar = new Button("❌ Cancelar Venta");
        btnCancelar.getStyleClass().add("boton-cancelar");
        btnCancelar.setOnAction(e -> {
            contenedor.getChildren().clear();
            contenedor.getChildren().add(outputArea);
        });

        HBox filaCancelar = new HBox(btnCancelar);
        filaCancelar.setAlignment(Pos.BOTTOM_RIGHT);
        form.getChildren().add(filaCancelar);
        contenedor.getChildren().add(form);
    }

    public  void mostrarVentanaSeleccionCliente(TextField campoDestino) {
        Stage ventana = new Stage();
        ventana.setTitle("Seleccionar Cliente");

        TableView<Cliente> tabla = new TableView<>();
        tabla.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Cliente, Integer> colID = new TableColumn<>("ID");
        colID.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Cliente, Integer> colDNI = new TableColumn<>("DNI");
        colDNI.setCellValueFactory(new PropertyValueFactory<>("DNI"));

        TableColumn<Cliente, String> colNombre = new TableColumn<>("Nombre");
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));

        TableColumn<Cliente, String> colApellido = new TableColumn<>("Apellido");
        colApellido.setCellValueFactory(new PropertyValueFactory<>("apellido"));

        tabla.getColumns().addAll(colID, colDNI, colNombre, colApellido);

        ArrayList<Cliente> lista = new ArrayList<>();
        ClienteDAO.cargarClientesEnLista(lista);
        tabla.getItems().addAll(lista);

        TextField txtBuscar = new TextField();
        txtBuscar.setPromptText("Ingrese DNI del cliente");

        Button btnBuscar = new Button("Buscar");
        btnBuscar.setOnAction(e -> {
            String dni = txtBuscar.getText().trim();
            ArrayList<Cliente> resultado = ClienteDAO.buscarClientePorDato("DNI", dni);
            tabla.getItems().setAll(resultado);
        });

        agregarDobleClickSeleccion(tabla, cliente -> {
            campoDestino.setText(String.valueOf(cliente.getId()));
            ventana.close();
        });


        VBox layout = new VBox(10, tabla, txtBuscar, btnBuscar);
        layout.setPadding(new Insets(10));

        Scene escena = new Scene(layout, 600, 400);
        ventana.setScene(escena);
        ventana.initModality(Modality.APPLICATION_MODAL);
        ventana.showAndWait();
    }
    private void mostrarVentanaSeleccionEmpleado(TextField campoDestino) {
        Stage ventana = new Stage();
        ventana.setTitle("Seleccionar Empleado");
        ventana.initModality(Modality.APPLICATION_MODAL);

        TableView<Empleado> tabla = new TableView<>();
        tabla.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Empleado, Integer> colID = new TableColumn<>("ID");
        colID.setCellValueFactory(new PropertyValueFactory<>("empleadoID"));

        TableColumn<Empleado, Integer> colDNI = new TableColumn<>("DNI");
        colDNI.setCellValueFactory(new PropertyValueFactory<>("dni"));

        TableColumn<Empleado, String> colNombre = new TableColumn<>("Nombre");
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));

        TableColumn<Empleado, String> colApellido = new TableColumn<>("Apellido");
        colApellido.setCellValueFactory(new PropertyValueFactory<>("apellido"));

        tabla.getColumns().addAll(colID, colDNI, colNombre, colApellido);

        ArrayList<Empleado> lista = new ArrayList<>();
        VentanaEmpleado.cargarEmpleadosEnLista(lista);
        tabla.getItems().addAll(lista);

        TextField txtBuscar = new TextField();
        txtBuscar.setPromptText("Ingrese DNI del empleado");

        Button btnBuscar = new Button("Buscar");
        btnBuscar.setOnAction(e -> {
            try {
                int dni = Integer.parseInt(txtBuscar.getText().trim());
                Integer id = VentanaEmpleado.obtenerIdEmpleadoPorDni(dni);
                if (id != null) {
                    for (Empleado emp : lista) {
                        if (emp.getEmpleadoID() == id) {
                            tabla.getItems().setAll(emp);
                            return;
                        }
                    }
                } else {
                    tabla.getItems().clear();
                }
            } catch (NumberFormatException ex) {
                mostrarAlerta("DNI inválido.");
            }
        });

        // ✅ Doble click para seleccionar automáticamente
        agregarDobleClickSeleccion(tabla, empleado -> {
            campoDestino.setText(String.valueOf(empleado.getEmpleadoID()));
            ventana.close();
        });

        VBox layout = new VBox(10, tabla, txtBuscar, btnBuscar);
        layout.setPadding(new Insets(10));

        Scene escena = new Scene(layout, 600, 400);
        ventana.setScene(escena);
        ventana.showAndWait();
    }

    /*public void ventasPorCliente() {
        contenedor.getChildren().clear();

        Label titulo = new Label("🧾 Ventas por Cliente");
        titulo.getStyleClass().add("titulo-seccion");

        // Campo para DNI
        TextField dniInput = new TextField();
        dniInput.setPromptText("Ingrese DNI del cliente");
        dniInput.getStyleClass().add("input-form");
        dniInput.setMaxWidth(200);

        Button buscarBtn = new Button("Buscar");
        buscarBtn.getStyleClass().add("btn-verde");
        buscarBtn.setPrefWidth(100);

        HBox buscador = new HBox(10, dniInput, buscarBtn);
        buscador.setAlignment(Pos.CENTER_LEFT);

        // Tabla de resultados
        TableView<Venta> tabla = new TableView<>();
        tabla.setPlaceholder(new Label("Ingrese un DNI para buscar."));
        tabla.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        tabla.getStyleClass().add("tabla-clientes");

        TableColumn<Venta, Integer> colFactura = new TableColumn<>("Factura");
        colFactura.setCellValueFactory(new PropertyValueFactory<>("idVenta"));

        TableColumn<Venta, String> colProducto = new TableColumn<>("Producto");
        colProducto.setCellValueFactory(new PropertyValueFactory<>("notas"));

        TableColumn<Venta, String> colEmpleado = new TableColumn<>("Empleado");
        colEmpleado.setCellValueFactory(new PropertyValueFactory<>("nombreEmpleado"));

        TableColumn<Venta, Integer> colCantidad = new TableColumn<>("Cantidad");
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));

        TableColumn<Venta, String> colFecha = new TableColumn<>("Fecha");
        colFecha.setCellValueFactory(new PropertyValueFactory<>("fechaFormateada"));

        TableColumn<Venta, String> colPago = new TableColumn<>("Pago");
        colPago.setCellValueFactory(new PropertyValueFactory<>("medioPago"));

        TableColumn<Venta, Double> colTotal = new TableColumn<>("Total");
        colTotal.setCellValueFactory(new PropertyValueFactory<>("importeTotal"));

        tabla.getColumns().addAll(colFactura, colProducto, colEmpleado, colCantidad, colFecha, colPago, colTotal);

        // Acción de búsqueda
        buscarBtn.setOnAction(e -> {
            try {
                int dni = Integer.parseInt(dniInput.getText().trim());
                Integer id = ClienteDAO.obtenerIdClientePorDni(dni);

                if (id != null) {
                    ArrayList<Venta> ventas = VentaDAO.obtenerVentasPorCliente(id);
                    if (ventas.isEmpty()) {
                        tabla.setPlaceholder(new Label("❌ El cliente no tiene ventas registradas."));
                        tabla.getItems().clear();
                    } else {
                        tabla.getItems().setAll(ventas);
                    }
                } else {
                    mostrarAlerta("❌ No se encontró ningún cliente con ese DNI.");
                    tabla.getItems().clear();
                }
            } catch (NumberFormatException ex) {
                mostrarAlerta("❌ DNI inválido.");
            }
        });

        VBox tarjeta = new VBox(10, titulo, buscador, tabla);
        tarjeta.setPadding(new Insets(20));
        tarjeta.setAlignment(Pos.TOP_LEFT);
        tarjeta.setMaxWidth(Double.MAX_VALUE);
        tarjeta.getStyleClass().add("card");

        contenedor.getChildren().setAll(tarjeta);
    }*/
}